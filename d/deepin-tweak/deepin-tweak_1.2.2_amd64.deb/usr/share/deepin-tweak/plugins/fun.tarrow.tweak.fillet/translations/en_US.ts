<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1">
<context>
    <name>main</name>
    <message>
        <location filename="../main.qml" line="14"/>
        <source>Fillet size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.qml" line="15"/>
        <source>Adjust window fillet size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.qml" line="46"/>
        <source>Fillet size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.qml" line="72"/>
        <source>Reset to default</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.qml" line="91"/>
        <source>Apply</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
