// SPDX-FileCopyrightText: 2018 - 2022 UnionTech Software Technology Co., Ltd.
//
// SPDX-License-Identifier: GPL-3.0-or-later

#ifndef __CONVERT_H__
#define __CONVERT_H__

int svg_to_png(const char* file, const char* dest);

#endif
