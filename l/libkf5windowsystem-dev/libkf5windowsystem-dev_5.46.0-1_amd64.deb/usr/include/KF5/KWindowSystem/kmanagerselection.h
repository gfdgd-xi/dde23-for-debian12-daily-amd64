// KDE4 compatibility header
#include "kselectionowner.h"
#include "kselectionwatcher.h"
