// SPDX-FileCopyrightText: 2022 Uniontech Software Technology Co., Ltd.
//
// SPDX-License-Identifier: LGPL-3.0-or-later

#define DNOTIFICATIONS_NAMESPACE Dtk::Notifications

#define DNOTIFICATIONS_USE_NAMESPACE using namespace DNOTIFICATIONS_NAMESPACE;

#define DNOTIFICATIONS_BEGIN_NAMESPACE namespace Dtk { namespace Notifications {

#define DNOTIFICATIONS_END_NAMESPACE }}
