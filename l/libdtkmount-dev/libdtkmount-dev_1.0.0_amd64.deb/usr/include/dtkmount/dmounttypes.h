// SPDX-FileCopyrightText: 2022 UnionTech Software Technology Co., Ltd.
//
// SPDX-License-Identifier: LGPL-3.0-or-later

#ifndef DMOUNTTYPES_H
#define DMOUNTTYPES_H

#include <DtkMountGlobal>

DMOUNT_BEGIN_NAMESPACE

enum class ProtocolDeviceProperty {

};   // enum ProtocolDeviceProperty

enum class BlockDeviceProperty {

};   // enum BlockDeviceProperty

DMOUNT_END_NAMESPACE

#endif   // DMOUNTTYPES_H
