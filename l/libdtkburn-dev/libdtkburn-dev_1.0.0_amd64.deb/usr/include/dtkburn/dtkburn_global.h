// SPDX-FileCopyrightText: 2022 UnionTech Software Technology Co., Ltd.
//
// SPDX-License-Identifier: LGPL-3.0-or-later

#define DBURN_NAMESPACE Dtk::Burn

#define DBURN_USE_NAMESPACE using namespace DBURN_NAMESPACE;

#define DBURN_BEGIN_NAMESPACE \
    namespace Dtk {           \
    namespace Burn {
#define DBURN_END_NAMESPACE \
    }                       \
    }
